#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "serial.h"
#include "balance.h"
#include "key.h"
#include "timer.h"
#include "follow.h"
#include "key.h"


uint8_t mode ,open ;
int  i ;
float x ;

void mode_go(void)
{
	while(open == 1)
	{
	OLED_ShowNum(4,12,mode,1);
	OLED_ShowNum(3,1,open,1);
		
		switch(mode)
		{
			case 0 : follow_0();		break;    //si ��λ
			case 1 : follow_7();		break;		//�� ��λ
			case 2 : follow_8();		break;		//si ��
			case 3 : follow_6(); 		break;		//����
			case 4 : follow_9(); 		break;		//3
			case 5 : follow_9(); 		break;		//4
			case 6 : follow_10(); 		break;	//У��
		}
	}
}


int main(void)
{
	Servo_Init();	
	Serial_Init();
	OLED_Init();
	Timer_Init();
	EXTI_Configuration();
	GPIO_Configuration();
	Servo_SetAngle1(90); //x
	Servo_SetAngle2(90);  //y
	while (1)
	{
//		OLED_ShowNum(1,1,goal_1(),3);
//		OLED_ShowNum(1,5,goal_2(),3);
//		OLED_ShowNum(2,1,goal_3(),3);
//		OLED_ShowNum(2,5,goal_4(),3);
//		OLED_ShowNum(3,1,goal_5(),3);
//		OLED_ShowNum(3,5,goal_6(),3);
//		OLED_ShowNum(4,1,goal_7(),3);
//		OLED_ShowNum(4,5,goal_8(),3);
//		OLED_ShowNum(1,10,Data_1(),3);
//		OLED_ShowNum(2,10,Data_2(),3);

		OLED_ShowNum(1,1,mode,3);
		OLED_ShowNum(1,5,open,3);
		OLED_ShowNum(1,9,stop,3);
//		mode_go	();
//		follow_7();
//		follow_6();  
//		follow_9();
//		follow_10();
		mode_go();
	}
}





