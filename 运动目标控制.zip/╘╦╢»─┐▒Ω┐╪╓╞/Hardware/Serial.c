#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>

uint8_t U2_Flag;
uint8_t Serial_RxFlag;
uint8_t Data[6] = {0+48 , 7+48 , 0+48 , 0+48 , 6+48 , 5+48};
uint8_t Coord[24];
uint8_t Coord_1[24];
uint8_t RxData;
void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//��������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	//����ͨ�ų�ʼ��
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;//RX��TX
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//�����жϣ�����RXNE��־λ��NVIC�������
	//����NVIC
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;//�ж�ͨ��
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
}
void USART2_Init(void) 
	{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; // USART2_TX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; // USART2_RX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 9600;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART2, ENABLE);
}


void Serial_SendByte(uint8_t Byte) //�����ݴ�TX���ڴ����ȥ
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);//�������ݱ�־λ
}

uint8_t Serial_GetRxFlag(void)//�ж��Ƿ���RX���ݴ���
{
	if (Serial_RxFlag == 1)
	{
		Serial_RxFlag = 0;
		return 1;
	}
	return 0;
}

void USART1_Data1(void) 
{
		static uint8_t RxState = 0;
		static uint8_t pRxPacket = 0;
if (RxState == 0)
		{
			if (RxData == 0x46)
			{
				RxState = 1;
				pRxPacket = 0;
			}
		}
		else if (RxState == 1)
		{
			Data[pRxPacket] = RxData;
			pRxPacket ++;
			if (pRxPacket >= 6)
			{
				RxState = 2;
			}
		}
		else if (RxState == 2)
		{
			if (RxData == 0x45)
			{
				RxState = 0;
				Serial_RxFlag = 1;
			}
		}
}
void USART1_Data2(void) 
{
	static uint8_t RxState = 0;
	static uint8_t pRxPacket = 0;
	
	
	if (RxState == 0)
	{
		if (RxData == 0x41)
		{
			RxState = 1;
			pRxPacket = 0;
		}
	}
	else if (RxState == 1)
	{
		Coord[pRxPacket] = RxData;
		pRxPacket ++;
		if (pRxPacket >= 24)
		{
			RxState = 2;
		}
	}
	else if (RxState == 2)
	{
		if (RxData == 0x42)
		{
			RxState = 0;
			U2_Flag = 1;
		}
	}

	USART_ClearITPendingBit(USART1, USART_IT_RXNE);
}
void USART1_Data3(void) 
{
	static uint8_t RxState = 0;
	static uint8_t pRxPacket = 0;
	
	
	if (RxState == 0)
	{
		if (RxData == 0x43)
		{
			RxState = 1;
			pRxPacket = 0;
		}
	}
	else if (RxState == 1)
	{
		Coord_1[pRxPacket] = RxData;
		pRxPacket ++;
		if (pRxPacket >= 24)
		{
			RxState = 2;
		}
	}
	else if (RxState == 2)
	{
		if (RxData == 0x44)
		{
			RxState = 0;
			U2_Flag = 1;
		}
	}

	USART_ClearITPendingBit(USART1, USART_IT_RXNE);
}


void USART1_IRQHandler(void)//�жϽ������ݰ�
{

	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
	{
		RxData = USART_ReceiveData(USART1);
		USART1_Data1();
		USART1_Data2();
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
		
	}
}


float Data_1(void)
{
    return (Data[0]-48)*100+(Data[1]-48)*10+(Data[2]-48);
}

float Data_2(void)
{
    return (Data[3]-48)*100+(Data[4]-48)*10+(Data[5]-48);
}

//float Data_3(void)
//{
//	return Data[6]-48;
//}
//Uart_2

void Seria2_SendByte(uint8_t Byte) //�����ݴ�TX���ڴ����ȥ
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);//�������ݱ�־λ
}

uint8_t Uart2_GetRxFlag(void)
{
	if (U2_Flag == 1)
	{
		U2_Flag = 0;
		return 1;
	}
	else if(U2_Flag == 2)
	{
		U2_Flag = 0;
		return 2;
	}
	return 0;
}


float goal_1(void)
{
    return (Coord[0]-48)*100+(Coord[1]-48)*10+(Coord[2]-48);
}

float goal_2(void)
{
    return (Coord[3]-48)*100+(Coord[4]-48)*10+(Coord[5]-48);
}
float goal_3(void)
{
    return (Coord[6]-48)*100+(Coord[7]-48)*10+(Coord[8]-48);
}

float goal_4(void)
{
    return (Coord[9]-48)*100+(Coord[10]-48)*10+(Coord[11]-48);
}
float goal_5(void)
{
    return (Coord[12]-48)*100+(Coord[13]-48)*10+(Coord[14]-48);
}

float goal_6(void)
{
    return (Coord[15]-48)*100+(Coord[16]-48)*10+(Coord[17]-48);
}
float goal_7(void)
{
    return (Coord[18]-48)*100+(Coord[19]-48)*10+(Coord[20]-48);
}

float goal_8(void)
{
    return (Coord[21]-48)*100+(Coord[22]-48)*10+(Coord[23]-48);
}




float go_1(void)
{
    return (Coord_1[0]-48)*100+(Coord_1[1]-48)*10+(Coord_1[2]-48);
}

float go_2(void)
{
    return (Coord_1[3]-48)*100+(Coord_1[4]-48)*10+(Coord_1[5]-48);
}
float go_3(void)
{
    return (Coord_1[6]-48)*100+(Coord_1[7]-48)*10+(Coord_1[8]-48);
}

float go_4(void)
{
    return (Coord_1[9]-48)*100+(Coord_1[10]-48)*10+(Coord_1[11]-48);
}
float go_5(void)
{
    return (Coord_1[12]-48)*100+(Coord_1[13]-48)*10+(Coord_1[14]-48);
}

float go_6(void)
{
    return (Coord_1[15]-48)*100+(Coord_1[16]-48)*10+(Coord_1[17]-48);
}
float go_7(void)
{
    return (Coord_1[18]-48)*100+(Coord_1[19]-48)*10+(Coord_1[20]-48);
}

float go_8(void)
{
    return (Coord_1[21]-48)*100+(Coord_1[22]-48)*10+(Coord_1[23]-48);
}


