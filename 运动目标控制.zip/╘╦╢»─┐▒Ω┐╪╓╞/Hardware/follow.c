#include "stm32f10x.h"   
#include "Servo.h"
#include "serial.h"
#include "pid.h"
#include "OLED.h"
#include "Delay.h"
#include "key.h"


float follow_x=75 , follow_y=95 , err_x_0 , err_y_0 , err_x ,err_y , goal1 , goal2 , goal3 , goal4 , goal5 , goal6 , goal7 , goal8;
uint8_t flog_receive ,aim_x =70 , aim_y = 65  ;
uint8_t stop ;
int z ,p  ,t ,d = 5;

void followx(void)          //pa0
{
		if(follow_x<30)
    {
     follow_x = 30 ;
    }
    else if(follow_x>150)
    {
     follow_x = 150;
    }
		Servo_SetAngle1(follow_x);
}



void followy(void) 				  //pa1	B   
{
    if(follow_y<45)
    {
     follow_y = 45 ;
    }
    else if(follow_y>140)
    {
     follow_y = 140;
    }
    Servo_SetAngle2(follow_y);
}


void follow(void)
{
//    if(Serial_GetRxFlag() == 1)
//    {
        follow_x += (Data_1() - aim_x)/25;
        followx();
        follow_y += (Data_2() - aim_y)/25 ;
        followy();
//    }

}



void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
	{

//		switch(stop)
//		{
//			case 0 : follow(); break;
//			case 1 : suspend(); break;
//		}
		
		follow();

		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

void follow_0(void)
{
aim_x = 80;
aim_y = 60;
	while(1)
	{

			Serial_SendByte(1+48);
			Delay_ms(10);
		
	}
}

void follow_1(void)
{
aim_x = 26;
aim_y = 8;
}

void follow_2(void)
{
aim_x = 133;
aim_y = 6;
}
void follow_3(void)
{
aim_x = 134;
aim_y = 113;
}
void follow_4(void)
{
aim_x = 30;
aim_y = 111;
}

void follow_5(void)
{
	follow_1();
		for(z=0;z<300;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	follow_2();
		for(z=0;z<300;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}	
	follow_3();
		for(z=0;z<300;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	follow_4();
		while(1)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
			
}

void follow_6(void)
{
		t=500/d;
		for(z=0;z<20;z++)
		{
		Serial_SendByte(2+48);
		Delay_ms(50);
			
		}

		err_x_0 = (goal_3() - goal_1())/21;
		err_y_0 = (goal_4() - goal_2())/30;
		goal1 = goal_1();
		goal2 = goal_2();
		goal3 = goal_3();
		goal4 = goal_4();
		goal5 = goal_5();
		goal6 = goal_6();
		goal7 = goal_7();
		goal8 = goal_8();
		aim_x = goal1;
		aim_y = goal2;
//	while(1)
//	{
//	for(z=0;z<t;z++)
//			{
//				Serial_SendByte(1+48);
//				Delay_ms(10);
//			}
//	}
	for(z=0;z<400;z++)
	{
		Serial_SendByte(1+48);
		Delay_ms(10);
	}
	
	
	err_x = goal3 - goal1;
	err_y = goal4 - goal2;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d + goal1;
	aim_y = err_y*p/d + goal2;
		for(z=0;z<t;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	}
	
	
	err_x = goal5 - goal3;
	err_y = goal6 - goal4;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d+goal3;
	aim_y = err_y*p/d+goal4;
		for(z=0;z<t;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	}
	
	
	
	err_x = goal7 - goal5;
	err_y = goal8 - goal6;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d+goal_5();
	aim_y = err_y*p/d+goal_6();
		for(z=0;z<t;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	}
	
	
	err_x = goal1 - goal7;
	err_y = goal2 - goal8;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d+goal7;
	aim_y = err_y*p/d+goal8;
	for(z=0;z<t;z++)
		{
			Serial_SendByte(1+48);
			Delay_ms(10);
		}
	}


	while(1)
	{
			Serial_SendByte(1+48);
			Delay_ms(10);
	}
}

void follow_7(void)
{
		for(z=0;z<40;z++)
		{
		Serial_SendByte(2+48);
		Delay_ms(50);
			
		}

		err_x_0 = (goal_3() - goal_1())/2 + goal_1();
		err_y_0 = (goal_8() - goal_2())/2 + goal_2(); 

		aim_x = err_x_0;
		aim_y = err_y_0;

	while(1)
	{
			Serial_SendByte(1+48);
			Delay_ms(10);
	}
}



void follow_8(void)
{
			follow_1();
			for(z = 0 ;z<500 ;z++)
		{
				OLED_ShowNum(1,1,mode,3);
				Serial_SendByte(1+48);
				Delay_ms(10);
		}
			follow_2();
				for(z = 0 ;z<500 ;z++)
		{
				OLED_ShowNum(1,1,mode,3);
				Serial_SendByte(1+48);
				Delay_ms(10);
		}
		follow_3();
				for(z = 0 ;z<500 ;z++)
		{
				OLED_ShowNum(1,1,mode,3);
				Serial_SendByte(1+48);
				Delay_ms(10);
		}
		follow_4();
				for(z = 0 ;z<500 ;z++)
		{
				OLED_ShowNum(1,1,mode,3);
				Serial_SendByte(1+48);
				Delay_ms(10);
		}
		follow_1();
				for(z = 0 ;z<500 ;z++)
		{
				OLED_ShowNum(1,1,mode,3);
				Serial_SendByte(1+48);
				Delay_ms(10);
		}
}

void follow_9(void)
{
		t=500/d;
		for(z=0;z<40;z++)
		{
		Serial_SendByte(3+48);
		Delay_ms(50);
			
		}

		err_x_0 = (goal_3() - goal_1())/21;
		err_y_0 = (goal_4() - goal_2())/30;
		goal1 = goal_1();
		goal2 = goal_2();
		goal3 = goal_3();
		goal4 = goal_4();
		goal5 = goal_5();
		goal6 = goal_6();
		goal7 = goal_7();
		goal8 = goal_8();
		aim_x = goal1;
		aim_y = goal2;
//	while(1)
//	{
//	for(z=0;z<t;z++)
//			{
//				Serial_SendByte(1+48);
//				Delay_ms(10);
//			}
//	}
	for(z=0;z<400;z++)
	{
		Serial_SendByte(1+48);
		Delay_ms(10);
	}
	
	
	err_x = goal3 - goal1;
	err_y = goal4 - goal2;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d + goal1;
	aim_y = err_y*p/d + goal2;
		for(z=0;z<t;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	}
	
	
	err_x = goal5 - goal3;
	err_y = goal6 - goal4;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d+goal3;
	aim_y = err_y*p/d+goal4;
		for(z=0;z<t;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	}
	
	
	
	err_x = goal7 - goal5;
	err_y = goal8 - goal6;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d+goal_5();
	aim_y = err_y*p/d+goal_6();
		for(z=0;z<t;z++)
			{
				Serial_SendByte(1+48);
				Delay_ms(10);
			}
	}
	
	
	err_x = goal1 - goal7;
	err_y = goal2 - goal8;
	for(p=0 ;p<=d ;p++)
	{
	aim_x = err_x*p/d+goal7;
	aim_y = err_y*p/d+goal8;
	for(z=0;z<t;z++)
		{
			Serial_SendByte(1+48);
			Delay_ms(10);
		}
	}


	while(1)
	{
			Serial_SendByte(1+48);
			Delay_ms(10);
	}
}

void	follow_10(void)
{
	mode = 1;
	while(1)
	{
		switch(mode)
		{
			case 1 : follow_0();	break;
			case 2 : follow_1();	break;
			case 3 : follow_2();	break;
			case 4 : follow_3();	break;
			case 5 : follow_4();	break;
		}
		for(z = 0 ;z<500 ;z++)
		{
				OLED_ShowNum(1,1,mode,3);
				Serial_SendByte(1+48);
				Delay_ms(10);
		}
		mode++;
		if(mode == 6)
		{
		mode = 1;
		}
			
	}
	
}
	
	
