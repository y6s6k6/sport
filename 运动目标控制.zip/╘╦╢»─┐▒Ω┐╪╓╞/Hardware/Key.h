#ifndef __MATRIXKEY_H
#define __MATRIXKEY_H

extern uint8_t  mode ,open , stop;
void EXTI_Configuration(void);
void GPIO_Configuration(void);

#endif
