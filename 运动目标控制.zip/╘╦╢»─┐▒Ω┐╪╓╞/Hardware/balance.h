#ifndef __BALANCE_H
#define __BALANCE_H

	void balance (void);

#endif
