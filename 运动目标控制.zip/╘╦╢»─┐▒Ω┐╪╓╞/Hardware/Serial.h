#ifndef __SERIAL_H
#define __SERIAL_H

extern uint8_t Data[7];
void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
uint8_t Serial_GetRxFlag(void);
float Data_1(void);
float Data_2(void);
//float Data_3(void);
void USART2_Init(void);
void Seria2_SendByte(uint8_t Byte);
uint8_t Uart2_GetRxFlag(void);
void USART1_Data2(void);
float goal_1(void);
float goal_2(void);
float goal_3(void);
float goal_4(void);
float goal_5(void);
float goal_6(void);
float goal_7(void);
float goal_8(void);
float go_1(void);
float go_2(void);
float go_3(void);
float go_4(void);
float go_5(void);
float go_6(void);
float go_7(void);
float go_8(void);




#endif
