#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_rcc.h"
#include "Delay.h"


extern uint8_t  mode ,open , stop;


void EXTI_Configuration(void) 
	{
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource5);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource6);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource7);

    EXTI_InitStructure.EXTI_Line = EXTI_Line5 | EXTI_Line6 | EXTI_Line7;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00; 
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;        
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
		
		
}

void GPIO_Configuration(void) 
	{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;  
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void EXTI9_5_IRQHandler(void)
	{
    if (EXTI_GetITStatus(EXTI_Line5) != RESET) 
			{
				mode++;
				if(mode == 9)
				{
				mode = 0;
				}
				Delay_ms(20);
				while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5) == 0);
				Delay_ms(20);
				
        EXTI_ClearITPendingBit(EXTI_Line5);
			}

			if (EXTI_GetITStatus(EXTI_Line6) != RESET) 
			{
				if(open == 0)
				{
				open =1 ;
				}
				else if(open == 1)
				{
				open = 2;
				}
				else
				{
				open = 0;
				}
				Delay_ms(20);
				while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6) == 0);
				Delay_ms(20);
				
				
        EXTI_ClearITPendingBit(EXTI_Line6);
			}

    if (EXTI_GetITStatus(EXTI_Line7) != RESET) 
			{
				if(stop == 0)
				{
				stop = 1 ;
				}

				else
				{
				stop = 0;
				}
				Delay_ms(20);				
				while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);
				Delay_ms(20);
				
        
				
				while(stop==1)
					{
							if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0)
							{
							stop =0;
								
							}
							Delay_ms(20);
							while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);
							Delay_ms(20);
					}
				EXTI_ClearITPendingBit(EXTI_Line7);
			}
}
	
