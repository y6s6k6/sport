#ifndef __FOLLOW_H
#define __FOLLOW_H

extern uint8_t  l;
void follow_0(void);
void follow_1(void);
void follow_2(void);
void follow_3(void);
void follow_4(void);
void follow_5(void);
void follow_6(void);
void follow_7(void);
void follow_8(void);
void follow_9(void);
void follow_10(void);

#endif
