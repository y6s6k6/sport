#ifndef __PID_H
#define __PID_H

float pid_place_x(float setpoint, float input, float kp, float ki, float kd, float dt);
float pid_place_y(float setpoint, float input, float kp, float ki, float kd, float dt);

#endif
