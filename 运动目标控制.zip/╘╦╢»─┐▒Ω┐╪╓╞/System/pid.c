#include "stm32f10x.h"   



float pid_place_x(float setpoint, float input, float kp, float ki, float kd, float dt)
{
    static float integral;
    static float prev_error;
    static float integral_max = 1000000;
    float error = setpoint - input;
    integral += error * dt;
    if(integral>integral_max)
    {
    integral = integral_max;
    }
    else if(integral<-integral_max)
    {
    integral = integral_max;
    }

    float derivative = (error - prev_error) / dt;
    float output = kp * error + ki * integral + kd * derivative;
    prev_error = error;
//    OLED_ShowSignedNum(1,1,error,5);                OLED_ShowSignedNum(1,9,integral,5);
//    OLED_ShowSignedNum(2,1,derivative,5);           OLED_ShowSignedNum(2,9,output,5);
//    OLED_ShowSignedNum(3,1,setpoint,5);             OLED_ShowSignedNum(3,9,input,5);

return output;
}



float pid_place_y(float setpoint, float input, float kp, float ki, float kd, float dt)
{
    static float integral;
    static float prev_error;
    static float integral_max = 1000000;
    float error = setpoint - input;
    integral += error * dt;
    if(integral>integral_max)
    {
    integral = integral_max;
    }
    else if(integral<-integral_max)
    {
    integral = integral_max;
    }

    float derivative = (error - prev_error) / dt;
    float output = kp * error + ki * integral + kd * derivative;
    prev_error = error;
//    OLED_ShowSignedNum(1,1,error,5);                OLED_ShowSignedNum(1,9,integral,5);
//    OLED_ShowSignedNum(2,1,derivative,5);           OLED_ShowSignedNum(2,9,output,5);
//    OLED_ShowSignedNum(3,1,setpoint,5);             OLED_ShowSignedNum(3,9,input,5);

return output;
}
